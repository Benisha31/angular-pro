import { Cancellation } from './cancellation';

describe('Cancellation', () => {
  it('should create an instance', () => {
    expect(new Cancellation()).toBeTruthy();
  });
});
