export class Login {
    custId:string;
    password:string;
    role:string;
}
