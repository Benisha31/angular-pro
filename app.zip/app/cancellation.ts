export class Cancellation {
  custId:string;
  bookingId:number;
  scheduleId:number;
  dateOfCancelling:string;
  numOfSeatsCancelled:number;
  seatNo:number;
}
