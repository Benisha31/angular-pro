import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{RouterModule,Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ScheduleListComponent } from './component/schedule-list/schedule-list.component';
import { ScheduleServiceService } from './service/schedule-service.service';
import{HttpModule} from '@angular/http'
import { ScheduleFormComponent } from './component/schedule-form/schedule-form.component';
import{FormsModule} from '@angular/forms';
import { LoginComponent } from './component/login/login.component';
import { CustomerComponent } from './component/customer/customer.component';
import { AdminComponent } from './component/admin/admin.component';
import { CancellationComponent } from './component/cancellation/cancellation.component';
import {AgGridModule} from 'ag-grid-angular/main';
import { FilterPipe } from './pipe.pipe';
import { ReservationComponent } from './component/reservation/reservation.component';
import { CustomersComponent } from './component/customers/customers.component';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'admin',component:AdminComponent},
  {path:'customer',component:CustomerComponent},
  {path:'schedule',component:ScheduleListComponent},
  {path:'new',component:ScheduleFormComponent},
  {path:'cancel',component:CancellationComponent},
  {path:'reservation',component:ReservationComponent},
  {path:'customers',component:CustomersComponent},

];
@NgModule({
  declarations: [
    AppComponent,
    ScheduleListComponent,
    ScheduleFormComponent,
    LoginComponent,
    CustomerComponent,
    AdminComponent,
    CancellationComponent,
    FilterPipe,
    ReservationComponent,
    CustomersComponent
    
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpModule,
    RouterModule.forRoot(routes),
    AgGridModule.withComponents([])

  ],
  providers: [ScheduleServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
