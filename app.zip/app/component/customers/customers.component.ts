import { Component, OnInit } from '@angular/core';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Router } from '@angular/router';
import { Customers } from 'src/app/customers';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router) { }
customer:Customers
  ngOnInit() {
    this.scheduleServiceService.getCustomers().subscribe((customer)=>{
      console.log(customer);
      this.customer=customer;
    },(error)=>{
      console.log(error);
    })
  }
Home(){
  this._router.navigate(['/admin']);
}

}
