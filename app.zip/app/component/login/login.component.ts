import { Component, OnInit } from '@angular/core';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Router } from '@angular/router';
import { Customers } from 'src/app/customers';
import { Login } from 'src/app/login';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
private log:Login;
  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router ) { }

  ngOnInit() {
    this.log=this.scheduleServiceService.getters();
  }
login(log){
  console.log(log.role);
 
  this.scheduleServiceService.getCustomer(log).subscribe((data)=>{
    console.log(data); 
if(data){
    if(log.role=='Admin')
    {
    
      this._router.navigate(['/admin']);
    }else if(log.role=='Customer')
    {
    
      this._router.navigate(['/customer']);
    }
  }else{
    alert("Invalid credentials!! ")
  }
  },(error)=>{
          })
}

  
}
