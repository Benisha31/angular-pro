import { Component, OnInit } from '@angular/core';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Cancellation } from 'src/app/cancellation';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cancellation',
  templateUrl: './cancellation.component.html',
  styleUrls: ['./cancellation.component.css']
})
export class CancellationComponent implements OnInit {
  cancel: Cancellation;


  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router) { }

  ngOnInit() {
    this.scheduleServiceService.getCancellation().subscribe((cancel)=>{
      console.log(cancel);
      this.cancel=cancel;
    },(error)=>{
      console.log(error);
    })
  }
Home(){
  this._router.navigate(['/admin']);
}
}
