import { Component, OnInit } from '@angular/core';
import { Schedule } from 'src/app/schedule';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule-form',
  templateUrl: './schedule-form.component.html',
  styleUrls: ['./schedule-form.component.css']
})
export class ScheduleFormComponent implements OnInit {
  private schedule:Schedule;
  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router) { }

  ngOnInit() {
    this.schedule=this.scheduleServiceService.getter()

  }
  processForm(){
      if(this.schedule.scheduleId==undefined){
        this.scheduleServiceService.addSchedule(this.schedule).subscribe((data)=>{
          console.log(data);
          this._router.navigate(['/schedule']);
        },(error)=>{
          console.log(error);
          alert("Please enter valid details!!")

        })
      }else{
        this.scheduleServiceService.editSchedule(this.schedule).subscribe((schedule)=>{
          console.log(schedule);
          this._router.navigate(['/schedule']);
        },(error)=>{
          console.log(error);
        })
      }
  }

}
