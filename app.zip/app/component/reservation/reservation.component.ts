import { Component, OnInit } from '@angular/core';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Router } from '@angular/router';
import { Reservation } from 'src/app/reservation';

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.css']
})
export class ReservationComponent implements OnInit {
reservation:Reservation
  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router) { }

  ngOnInit() { this.scheduleServiceService.getReservation().subscribe((reservation)=>{
    console.log(reservation);
    this.reservation=reservation;
  },(error)=>{
    console.log(error);
  })
}
Home(){
this._router.navigate(['/admin']);
}
  

}
