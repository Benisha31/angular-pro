import { Component, OnInit } from '@angular/core';
import { Schedule } from 'src/app/schedule';
import { ScheduleServiceService } from 'src/app/service/schedule-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule-list',
  templateUrl: './schedule-list.component.html',
  styleUrls: ['./schedule-list.component.css']
})
export class ScheduleListComponent implements OnInit {
  private schedule:Schedule[];
  private sche:Schedule[];

  public searchString: string;


  constructor(private scheduleServiceService:ScheduleServiceService,private _router:Router) { }

  ngOnInit() {
    this.scheduleServiceService.getSchedule().subscribe((schedule)=>{
      console.log(schedule);
      this.schedule=schedule;
    },(error)=>{
      console.log(error);
    })

  }

  deleteSchedule(schedule){
    this.scheduleServiceService.deleteSchedule(schedule.scheduleId).subscribe((data)=>{
      this.schedule.splice(this.schedule.indexOf(schedule),1);
    },(error)=>{
      console.log(error);
    }
    )
  }
  updateSchedule(schedule){
    this.scheduleServiceService.setter(schedule);
    this._router.navigate(['/new']);
  }
  newSchedule(){
    let schedule=new Schedule();
    this.scheduleServiceService.setter(schedule);
    this._router.navigate(['/new']);
  }
    
       
    
   }
  
