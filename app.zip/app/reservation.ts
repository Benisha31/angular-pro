export class Reservation {
   custId:string;
    bookingId:number;
    dateOfBooking:String;
    scheduleId:number;
    numofseatswanted:number;
     seatNo:number;
}
